# LIN3-TCR
BOT Chivas Edited V.2 Login Token / Link

Catatan : 
- Bot Ini Menggunakan 10 Akun Bot + 1 Akun admin <br>

Cara Install Via Android :
- Download Termux & Install di play store
?Lalu buka termux ketik?
pkg install python2
pip2 install rsa
pip2 install requests
pip2 install thrift==0.9.3
pkg install git
pkg install nano
git clone https://github.com/andyihsan/LIN3-TCR
Selesai

Cara Membuka/Mengedit File :
- Wajib Pakai Keyboard Hacker Download di PS<br>
- cd LIN3-TCR && nano line-tcr.py<br>
- Selesai Edit Save CTRL + X Lalu Y, Dan Enter<br>
- Keluarkan Termux<br>

Cara Membuka/Mengedit File Via Internal :
- Smartphone Telah Di Root<br>
- masuk root/data/data/com.termux/file/home/LIN3-TCR/line-tcr.py<br>

Cara Menjalankan Bot :
- Ketik di termux [cd LIN3-TCR[enter]python2 line-tcr.py]
- Loginkan Dengan Akun Bot Kalian Lalu Masukkan MID Admin

Butuh Bantuan? Silahkan Masuk Ke Group, add : andyihsan ( khusus yg udah tau bot aja )
